# Modular Project Planning Webapp — Specification v0.2

**Supersedes:** v0.1
**Working name:** TBD

---

## 1. What this is

A notebook that can guide you.

The user picks what they're making. The app assembles a workspace out of pre-built, opinionated **modules** — a character sheet that already knows to ask about want vs. need, a research module that already knows the sequence from question to method to data. The user can then add, remove, and rearrange modules freely, including ones from other project types.

### 1.1 The two halves

**Guidance** comes from the modules themselves. Each ships with real structure: named fields, craft-informed prompts under each field, a short intro explaining why the module matters. A blank Notion page teaches nothing. A character sheet asking "what does she want, and what does she actually need instead?" teaches something on first contact.

**Modularity** comes from the library. Every module in the app is available to every project. The starter bundle is a strong default, not a cage. A business project can add Three-Act Structure to shape a pitch. A novelist can add the academic Sources module for historical research.

### 1.2 Positioning

| Tool | Gives you |
|---|---|
| Notion | Lego. Build your own character sheet. |
| Reedsy | A finished character sheet — but only for books. |
| **This** | Finished sheets for many kinds of project, assembled by the user. |

Reedsy's insight is that opinionated structure is *more* useful than flexible structure, because it encodes knowledge the user doesn't have yet. The product here is that insight, generalised past fiction.

### 1.3 Design principles

1. **Opinionated by default, editable by choice.** Never open empty. Never lock.
2. **Every field earns its place.** A field with no prompt behind it is just a form. Twelve well-chosen fields beat forty.
3. **Capture is free.** Getting a thought in requires no decision about where it goes.
4. **Nothing is destroyed.** Removing a module hides it; the data stays and returns if re-added.

---

## 2. Creating a project

### 2.1 Step 1 — What are you making?

```
✦  CREATIVE          🎓  SCHOOL / ACADEMIC     💼  PROFESSIONAL
   Novel                 Research project          Business idea
   Short story           Essay                     Research
   Screenplay            Presentation              Presentation
   Comic                 Science project           Campaign
   Game                  Study / revision          Product / project
   Worldbuilding
   Poetry collection

🎨  PERSONAL          ⚙️  CUSTOM
   Portfolio             Build your own workspace
   Personal website
   Event
   Trip
   Life project
```

Custom starts with only the Rant Space and opens the module library directly.

### 2.2 Step 2 — Working title

Title plus an optional line of description. A "name it later" option generates a placeholder, since being asked to name a thing you haven't had yet is a genuine blocker.

### 2.3 Step 3 — Specifications

Free text ("what do you have in mind?") plus suggested tag chips based on the subtype — for Novel: fantasy, literary, YA, mystery, sci-fi, historical. Free entry always allowed. Tags refine which modules are pre-selected and which examples appear inside them.

### 2.4 Step 4 — Where are you?

- **I know what this is** → execution modules load first; structure modules pre-filled where possible
- **I have a vague idea** → structure modules load first, prompts weighted toward shaping
- **I just know I want to make one** → fewer modules, heavier prompting, Rant Space front and centre

This is not a "no idea" user in the useless sense. Someone who knows they want to write a novel but not which novel is a real person with real material — they just can't see it yet. The scaffold *is* the ideation tool: a three-act structure with empty slots and a question in each one does more than a blank page, because being asked what your protagonist wants and having no answer is itself progress.

Readiness is mutable. Changing it adds modules; it never removes them.

### 2.5 Step 5 — Confirm your workspace

Show the proposed module set as a checklist with one-line descriptions. Uncheck anything. "Add more" opens the library. This screen is where the user learns modules are optional, so it should not be skippable on first project.

---

## 3. Module system

### 3.1 Anatomy

```
Module {
  id, name, icon, category
  presentation:  sheet | slots | list | board | timeline | gallery | doc | table
  intro:         2–3 sentences on what this is for and why it matters
  entry_schema:  [ Field ]
  prompts:       per-field guidance text
  suggested_with: [module_id]   // "people who add this also add…"
  links_to:      [module_id]    // cross-references
}

Field {
  key, label, type, prompt, placeholder, required(false), repeatable
  type ∈ text | longtext | select | multiselect | date | number
       | image | link | reference | checklist | rating
}
```

Each module ships with a **fixed presentation**. There is no view-type switcher — a character sheet is a sheet, a beat sheet is slots, a scene list is a list. Letting users re-render a character sheet as a kanban board adds configuration burden and subtracts opinion, which is the thing we're selling.

`reference` fields point at entries in other modules. A scene can reference characters; a character can reference locations. This produces backlinks without needing a graph UI.

### 3.2 What makes a module good

Demonstrated on the **Character Sheet**, since it's the module people will judge the product by:

| Field | Prompt shown to user |
|---|---|
| Name | — |
| Role | Protagonist, antagonist, foil, mentor, or something you can't name yet |
| In one line | If a reader remembers one thing about them, what is it? |
| What they want | The thing they're chasing. Concrete, external, statable in a sentence. |
| What they need | The thing that would actually help them — usually not the same, often the opposite |
| The lie they believe | What they've decided is true about themselves or the world that isn't |
| Wound | What happened that made the lie feel true |
| Arc | Where they start → where they end. "No change" is a valid and sometimes better answer. |
| Contradiction | One thing about them that doesn't fit the rest. People aren't consistent. |
| What they'd never do | Often more revealing than what they would |
| How they speak | Rhythm, vocabulary, what they avoid saying |
| Relationships | *(reference → Cast)* with a line on what each one costs them |
| First appears | *(reference → Scenes)* |
| Appearance | Last, deliberately. Rarely the useful part. |

Note what's happening: field order, field choice, and prompt wording are all carrying craft knowledge. "Appearance last, deliberately" is a small piece of teaching embedded in a form layout. **This is the entire product.** The engineering is forms and a schema registry; the value is knowing which twelve fields belong here and what to say under each one.

Source the field sets from craft books, syllabi, and professional practice rather than inventing taxonomies. Budget most of the build time here.

### 3.3 Adding and removing

A **module library** browser: searchable, grouped by category, each entry showing name, one-line description, field preview, and which project types recommend it. Any module can be added to any project.

Removing archives rather than deletes. Re-adding restores the data.

### 3.4 Custom modules (phase 3)

A builder letting users define their own module — name, icon, presentation, fields with types and prompts. Optionally shareable as a template. This is the honest endpoint of "entirely modular," but it should arrive only after the curated library proves itself, because a user-built module has no guidance in it and guidance is the point.

---

## 4. Module library

### 4.1 Universal — available to every project

| Module | Presentation | Purpose |
|---|---|---|
| **Rant Space** | timeline | Always present, cannot be removed. See §5. |
| Notes | list | Freeform, unstructured |
| Tasks | board | To do / doing / done |
| Timeline & Milestones | timeline | Dated checkpoints, deadline countdown |
| Sources & Research | table | Title, author, year, type, link, key takeaway, quote, tags |
| Inspiration | gallery | Images, links, quotes, screenshots; each with a "why this" field |
| Open Questions | list | Things unresolved; closing one records the answer |
| Decisions Log | list | What was chosen, what was rejected, why. Invaluable at month four. |
| Glossary | table | Terms, names, invented words — also feeds transcription vocabulary (§5.3) |
| Progress Log | timeline | Auto-populated from activity, plus manual entries |

### 4.2 Creative

**Structure**
- Three-Act Structure — slots for setup / inciting incident / turn one / midpoint / turn two / climax / resolution, each with a question
- Save the Cat Beat Sheet — 15 named beats
- Hero's Journey — 12 stages
- Kishōtenketsu — four movements, no conflict required; suited to comics and quieter fiction
- Freeform Outline — nested, for people who reject templates
- Chapter Plan — table: number, title, POV, purpose, word target, status
- Scene Cards — list: goal, conflict, outcome, POV, location, characters *(reference)*, status

**Character**
- Character Sheet (§3.2)
- Cast Overview — table of everyone, roles, first appearance
- Relationship Map — pairwise: how they met, what each wants from the other, what strains it
- Arc Tracker — each character's stated arc against scenes where it moves

**World**
- Geography & Places — location cards
- Cultures & Peoples
- Magic / Technology System — with a mandatory **Limits** field, since rules matter more than powers
- History & Timeline
- Factions & Power
- Language & Naming
- Rules of the World — what is impossible here

**Craft**
- Themes & Motifs — theme, where it appears, whether it's stated too plainly
- POV & Voice — tense, person, distance, sample paragraph
- Style Sheet — spellings, capitalisations, consistency decisions

**Form-specific**
- Comic: Page & Panel Plan (page, panels, beat, dialogue, art notes), Script
- Game: Core Loop, Mechanics, Systems, Levels/Content, Player Experience Goals
- Screenplay: Beat Board, Sequences, Scene Headings, Character Wants by Scene
- Poetry: Poem List, Forms & Constraints, Image Bank, Line Bank, Collection Order

### 4.3 School / Academic

- Research Question & Hypotheses — question, sub-questions, testable hypotheses, why it matters
- Literature Review — source cards with argument, method, findings, limitations, relevance to my question
- Methodology — approach, sample, procedure, instruments, ethics, why this method over alternatives
- Variables — independent, dependent, controlled, how each is measured
- Data & Observations — table, user-defined columns
- Analysis — findings against each hypothesis, supported/not/inconclusive
- Argument Map (essay) — thesis, claims, evidence per claim, counterarguments, rebuttals
- Essay Outline — intro, body sections, conclusion, with a "what does this paragraph do" field
- Citations — with style selector, exportable
- Rubric & Requirements — paste the brief, turn each requirement into a checkable item
- Science Project — hypothesis, materials, procedure, observations, results, conclusion, sources
- Study Project — syllabus breakdown, topic confidence rating, revision schedule, past papers, weak areas

### 4.4 Professional

- Problem & Opportunity — the problem, who has it, how they solve it now, why that's inadequate
- Customer / Audience — segment cards with needs, objections, where to reach them
- Value Proposition — for [X] who [Y], we provide [Z], unlike [W]
- Competitors — table with positioning and gaps
- Business Model — revenue, costs, unit economics, assumptions
- Go-to-Market — channels, sequence, first ten customers
- Risks & Assumptions — assumption, confidence, how to test it cheaply
- Campaign — audience, core message, channels, calendar, assets, KPIs
- Product Requirements — user stories, acceptance criteria, priority
- Roadmap — timeline of phases
- Presentation — audience & goal, one-sentence takeaway, narrative arc, slide outline, delivery notes, anticipated questions
- Meeting & Feedback Log

### 4.5 Personal

- Portfolio — piece list, selection criteria, ordering, artist statement, bio
- Website — sitemap, page content, design direction, references, tech decisions
- Event — guest list, budget, vendors, run of show, checklist, contingencies
- Trip — itinerary by day, bookings, budget, places to see, packing, documents
- Life Project — goal, why it matters, milestones, habits, obstacles, support

---

## 5. Rant Space

Present in every project, removable from none. It's the reason someone with a vague idea has anything to put in the modules.

### 5.1 Capture

- **Type** — plain textarea, no title, no tags, no formatting toolbar, autosaves
- **Record** — in-browser audio, live waveform, no length cap

Reachable from every module via a fixed button and a global hotkey; opens over the current screen without navigating away. Optional mood and tag, both skippable.

### 5.2 Review

Reverse-chronological stream with inline audio playback and transcript beneath. Full-text search across typed rants and transcripts. Filters by date, tag, mood, has-audio, and mined/unmined. Calendar heatmap of capture frequency. A **resurface** control that shows an old rant at random — the archive only pays off if it gets read again.

### 5.3 Transcription

Audio is stored permanently alongside the transcript. This is non-negotiable: transcription reliably mangles invented names, technical terms, and non-English proper nouns — exactly the highest-value words in the recording. A garbled word must always be recoverable by listening.

**Vocabulary biasing:** pass the project's existing character names, place names, and Glossary terms into the transcription request as a vocabulary hint. A name typed once by hand gets spelled correctly in every subsequent recording. Small feature, large effect on whether the app feels like it knows your project.

Options: Whisper API (~$0.006/min, best accuracy, real per-user cost) · in-browser Whisper via WASM (free and private, but a 40–150MB first-load and slow on cheap phones — which is where voice capture actually happens) · Web Speech API (free, Chrome-centric, live-only, weakest on unusual words). Recommend Whisper API for v1 with a minutes cap, revisit local later.

Long recordings upload in chunks so a closed tab doesn't lose the take.

### 5.4 Triage — the connective mechanism

Select any span of a rant → **Send to…** → a list of the modules currently in this project.

Choosing "Character Sheet" creates a new character seeded with the selected text and a link back to the source rant. The rant is unchanged; the mined span gets a subtle underline showing what it became. On the character, a chip reads "from a rant on 14 March" and opens the original, audio included.

The destination list being drawn from the project's active modules is what makes the two halves of the app one app.

**Optional AI assist**, off by default: propose extractions from a rant — this reads like a character, this is a research question, this is a task. Every suggestion requires explicit acceptance. Nothing is created silently, and the app must be fully usable with it off.

### 5.5 Recurrence (phase 2)

For the "I just know I want to make one" user, the rant pile is the raw material and its value is only visible in aggregate. Surface what repeats: nouns, images, and themes that keep reappearing across weeks, and pairs of entries from different months that echo each other.

Draw the line at observation. **"You've mentioned drowning eleven times"** is useful and verifiable. **"Your novel is about grief"** is presumptuous, frequently wrong, and irritating when wrong. Report patterns; let the user interpret.

---

## 6. Data model

```
users
  id, email, display_name, created_at, settings(jsonb)

projects
  id, user_id, title, description,
  category, subtype, spec_text, spec_tags(text[]), readiness,
  status(active|archived), target_date,
  created_at, updated_at, last_touched_at

module_definitions            -- the library; app-authored + user-authored
  id, key, name, icon, category, presentation,
  intro, entry_schema(jsonb), prompts(jsonb),
  suggested_with(text[]), author_id(nullable), is_public

project_modules               -- which modules this project has
  id, project_id, module_definition_id,
  custom_name, order_index, status(active|archived),
  config(jsonb), created_at

entries                       -- every card, character, source, task, beat
  id, project_id, project_module_id,
  title, values(jsonb),       -- keyed by field key from entry_schema
  status, order_index, created_at, updated_at

rants
  id, project_id, mode(text|audio), body_text,
  audio_url, transcript, transcript_status,
  duration_ms, mood, tags(text[]), created_at

links
  id, project_id,
  from_type(entry|rant), from_id, to_type(entry|rant), to_id,
  relation(derived_from|references|related), created_at
```

`entries.values` is JSONB keyed to the module's `entry_schema`, validated in the application layer against a schema registry. Schema changes are additive and versioned — adding a field to Character Sheet must never orphan existing characters.

`project_modules` is the whole modularity mechanism. Adding a module inserts a row; removing sets status to archived and leaves entries intact.

---

## 7. Guidance layer

What makes it a notebook that guides rather than a notebook with more fields.

- **Field prompts** — under every field, always visible on empty fields, collapsing to an info icon once filled
- **Module intros** — two or three sentences on first open explaining what this is for
- **Empty states** — a filled-in example rather than "No entries yet"
- **Gentle nudges**, dismissible, never blocking: an antagonist with no *want*, a magic system with no *limits*, a hypothesis with no method, a module untouched for a month
- **Suggested next modules** — "projects with a Cast Overview usually add Relationship Map"
- **Completeness, shown not scored** — which fields are empty, without a percentage that implies a filled form is a finished project

Everything here is dismissible. The failure mode is a tool that nags, and a nagging notebook gets closed.

---

## 8. Technical approach

| Layer | Choice |
|---|---|
| Frontend | Next.js (App Router), React, TypeScript |
| Styling | Tailwind + small shared component set |
| Forms | Schema-driven renderer — one component maps `entry_schema` to inputs; adding a module is data, not code |
| Text | Lightweight editor (Tiptap) on `longtext` fields only |
| Database | Postgres (Supabase) — JSONB, full-text search, row-level security |
| Auth | Supabase Auth |
| Storage | S3-compatible for audio and images |
| Transcription | Whisper API, queued, with vocabulary hints |
| Hosting | Vercel |

The schema-driven form renderer is the key build. Get it right and the entire module library becomes content authoring rather than feature development, which is what makes a library this large tractable for a small team.

---

## 9. Build phases

**Phase 1 — MVP.** Auth, dashboard, project wizard, schema-driven module renderer, `project_modules` add/remove, Rant Space with audio and transcription and manual triage, universal modules, plus one complete vertical: **Novel** (Three-Act, Character Sheet, Cast, Worldbuilding, Scene Cards, Themes). Markdown/JSON export.

*Ship criterion:* someone who knows only that they want to write a novel can use this for six weeks and end with a real outline.

**Phase 2 — Breadth.** Academic and Professional module sets, remaining Creative forms, reference fields and backlinks, recurrence surfacing, readiness transitions, PDF/DOCX export.

**Phase 3 — Openness.** Custom module builder, shareable templates, optional AI triage, offline PWA, read-only share links.

---

## 10. Open questions

1. **How many modules before the library overwhelms?** Fifty well-written modules is a strong product and a hard browse. Needs search, categories, and a genuinely good "recommended" default.
2. **Module versioning.** When Character Sheet gains a field in v2, do existing projects get it? *Recommendation: offer, don't impose.*
3. **Cross-project reuse.** Should a worldbuilding set be shareable between two novels in the same world?
4. **Transcription cost ceiling.** Free-tier minutes, or on-demand transcription rather than automatic?
5. **Where does the app stop?** Once the plan is complete, does the user write the novel here, or export and leave? Staying means building a manuscript editor and competing with Scrivener; leaving means a shorter lifecycle but a sharper product.
6. **Weak-scaffold domains.** Fiction, research, and engineering have canonical structures. Visual art, music, and poetry largely don't. Templates there risk feeling arbitrary — worth researching properly rather than inventing.
