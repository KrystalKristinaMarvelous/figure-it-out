# Spec v0.3 — Overview & Brainstorming

**Supplements:** v0.2 (module system, rant space, data model)
**Covers:** §11 Project Overview · §12 Brainstorming · additions to the data model and build phases

---

## 0. Three modes of thinking

The app now has three distinct places a thought can live, and the distinction between them is the architecture:

| Mode | Shape | Commitment | Question it answers |
|---|---|---|---|
| **Rant** | Chronological stream, unstructured | None | *What's in my head right now?* |
| **Brainstorm** | Many parallel candidates | None | *What could this be?* |
| **Modules** | Structured fields, one value each | Yes | *What is this?* |

Material flows **rant → brainstorm → module**. Backward movement is allowed — a module field can be sent back to brainstorm to be reconsidered — but the default direction is toward commitment.

This resolves the apparent overlap between the Prompted Brainstorm asking "what do they want?" and the Character Sheet having a `want` field. The brainstorm holds five possible answers and no decision. The sheet holds the decision. They are different objects.

---

## 11. Project Overview

The landing screen for every project. Answers *what am I making* before anything else loads.

### 11.1 Identity block

```
┌────────────────────────────────────────────────────────┐
│  THE WINTER CROWN                            🟡 Developing │
│  Creative → Novel                                       │
│                                                         │
│  A princess discovers that her sister's death may have  │
│  been arranged by the court.                            │
│                                                         │
│  Target  80,000 words     Deadline  December 2026       │
│  ████████░░░░░░░░░░░░░░░  31%    Last touched  2d ago   │
└────────────────────────────────────────────────────────┘
```

| Field | Notes |
|---|---|
| Title | Inline-editable. Still labelled a working title. |
| Type | Category → subtype, from the wizard |
| One-line idea | **The most important field on the screen.** Inline-editable, max ~200 chars. |
| Status | User-set, not derived. See 11.2. |
| Target | Type depends on project — word count, piece count, page count, submission date. Optional. |
| Deadline | Optional. Drives a countdown once inside 30 days. |
| Progress | Derived. Only shown when a target exists; otherwise omitted rather than faked. |
| Last touched | Plain relative time. |

**On the one-line idea:** it doubles as a forcing function. Being unable to write it is real information about where the project is, so the empty state should say so rather than nagging — *"Not sure yet? That's normal this early. Try the Prompted Brainstorm."* For a project at "I just know I want to make one" readiness, leave it empty by default and let filling it in be a visible milestone.

### 11.2 Status

User-set, six values, deliberately not computed:

🌱 **Seed** · 🟡 **Developing** · 🔵 **Drafting** · 🟠 **Revising** · ✅ **Done** · 💤 **Dormant**

Dormant is offered rather than imposed — after long inactivity, ask; never auto-demote. Status also drives the dashboard card in §3.1 of v0.2.

### 11.3 Project Pulse

A count per active module, each linking into that module, each with a delta.

```
IDEAS               47      +6 this week
CHARACTERS           8      +1
LOCATIONS           12      —
TIMELINE            23 events
RESEARCH             6 sources
OPEN QUESTIONS      14      +3
```

Implementation is a `COUNT` per `project_module`, with deltas from `created_at > now() - interval '7 days'`. Cheap, and it's the screen that makes a project feel alive between work sessions.

Rules:
- Only active modules appear. Empty modules show `0` rather than being hidden — an empty module is information.
- Labels come from the module's plural noun, not its name ("23 events", "6 sources").
- Open Questions going *up* is good and should not be styled as a warning. Not knowing more things is progress at the developing stage.

**No streaks.** Creative projects are legitimately intermittent, and a broken streak punishes people for having a life. The delta already shows momentum without implying failure when it's zero.

### 11.4 Gap detection — "You haven't figured out…"

Two tiers. The first covers most of the value.

#### Tier 1 — Structural (rule-based, MVP)

Deterministic, free, never wrong. Rules are declared per module in its definition:

| Rule | Example message |
|---|---|
| Key field empty on a key entry | Your antagonist has no *want* |
| Module-specific required pairing | Your magic system has no *limits* |
| Orphaned entry | Kesh appears in no scenes |
| Unused reference | Two sources haven't been cited anywhere |
| Stale open question | "How does the succession work?" has been open 41 days |
| Empty structural slot | Act Two has no midpoint |
| Empty module | Themes has been added but is empty |
| Academic variants | A hypothesis with no method; a rubric item with nothing attached |

#### Tier 2 — Semantic (model-assisted, phase 2, opt-in)

Reads across entries and surfaces holes that rules can't see:

> ⚡ Why does the antagonist need the princess alive?
> *Irae's plan requires the succession to stay contested, but his stated method removes the only other claimant.*

**Framing rules, non-negotiable:**

- Always phrased as a **question**, never an assertion. A question fails gracefully — "Why does the antagonist need her alive?" is generative even if the model's reasoning was wrong. "Your antagonist's motive is inconsistent" is just wrong when it's wrong.
- Maximum three shown at once. This is a nudge, not an audit.
- Every one is dismissible, and dismissal is permanent for that question.
- Never blocks, never appears as a badge or unread count.
- Off by default; enabled per project.
- One-tap **"Take this to brainstorm"** — opens a Prompted Brainstorm session seeded with the question. This is the useful part: the app noticed a hole *and* handed over a tool for filling it.

---

## 12. Brainstorming

Two modes. Build the second one first.

### 12.1 Prompted Brainstorm

The differentiating feature, and cheap to build. The engineering is a question-sequencer; the value is entirely in the prompt writing.

#### Entry

```
What are you trying to figure out?

  ☑ Character motivation      ☐ Themes
  ☐ Plot possibilities        ☐ Problems & obstacles
  ☐ Worldbuilding             ☐ "What if?"
```

Multi-select. Available topics vary by project type — an academic project sees *Research angle*, *Counterarguments*, *Method alternatives*; a business project sees *Customer objections*, *Failure modes*, *Positioning*.

A session can also start seeded: from a gap-detection question, from a specific entry ("brainstorm this character"), or from a rant fragment.

#### The session

One prompt at a time, full screen, nothing else on it.

```
You're developing a protagonist.

  What do they want?
  ┌──────────────────────────────────────┐
  │                                      │
  └──────────────────────────────────────┘
  + add another possibility

  [ Skip ]  [ I don't know yet ]  [ Another angle → ]
```

Mechanics that matter:

- **Multiple answers per prompt, encouraged.** The "+ add another possibility" affordance is the entire point of the mode. One answer is a form; five is a brainstorm. Star a favourite later, or don't.
- **"Another angle"** rephrases the same underlying question differently — *"What would they say they want if you asked them at 3am?"* Static alternates in v1, generated in phase 2.
- **"I don't know yet"** is a first-class answer, not a skip. It writes an Open Question into the project. Not knowing becomes a tracked artifact instead of a dead end — and it feeds the Pulse counter, so uncertainty is visibly accumulating into something.
- **Follow-ups adapt.** If the answer to *what do they want* mentions another character, the next prompt can ask about that relationship. Rule-based branching in v1.
- No timer, no forced ordering, no completion percentage. Leaving mid-session is normal and the session stays open.

#### Sample prompt set — Character motivation (fiction)

1. What do they want? *Concrete, external, statable in a sentence.*
2. What do they *think* they want? *Often the same, and the gap is the story when it isn't.*
3. What are they actually afraid of?
4. What would make them betray someone they love?
5. What do they refuse to admit?
6. If they got exactly what they wanted, what would it cost them?
7. Who knew them before they became this?

#### Sample prompt set — Research angle (academic)

1. What question are you actually asking? *One sentence, no sub-clauses.*
2. Who has already asked something close to this?
3. What would have to be true for your answer to be interesting?
4. What result would prove you wrong?
5. What can you actually measure, given what you have access to?
6. If you only got half the data you wanted, what could you still say?

#### Closing a session

A review screen listing every prompt and its answers. Per answer:

- **→ Send to module** — routes to the matching field (*what do they want* → Character Sheet `want`), creating the entry if needed
- **→ Keep as note**
- **→ Discard**

Unreviewed sessions stay open and are listed in the Brainstorm module; nothing is auto-committed to a module without the user choosing it.

#### Prompt library

Stored as data (`prompt_library`), authored per topic and project type, with alternates and follow-up rules. Same principle as the module fields in v0.2 §3.2: the engineering is small, the writing is the product. Source from craft books, research-methods texts, and design practice rather than inventing questions.

### 12.2 Freeform Canvas

An infinite canvas. Build after the prompted mode.

#### Objects

- Sticky notes, text, images, freehand drawing
- Arrows and connectors, **labelled** — "causes", "conflicts with", "leads to", "same person?"
- Frames/groups for clustering
- **Entry cards** — live references to real entries. A character card on the canvas *is* the character; editing it on the canvas updates the Character Sheet and vice versa.

Entry cards are the only reason to build this rather than telling users to open Miro. Everything else here is a commodity.

#### Behaviour

- Multiple named canvases per project
- Drag any entry from any module onto a canvas
- Select a cluster → **make this into…** → creates an entry in a chosen module, seeded from the cluster's contents, with a link back
- Links created on canvas become `links` rows, so they show as backlinks inside modules

#### Honest scoping

This is the most expensive component in the whole app and the least differentiated. `tldraw` gets most of the way there (canvas, shapes, arrows, undo, persistence as a JSON document) and custom shapes handle entry cards. Budget several weeks even so. If the schedule slips, cut this — the prompted mode, the modules, and the rant space are a complete product without it.

---

## 13. Data model additions

```
projects
  + status(seed|developing|drafting|revising|done|dormant)
  + one_liner(text)
  + target_type(words|pieces|pages|date|none), target_value
  + deadline(date)

brainstorm_sessions
  id, project_id, topics(text[]), seed_type(gap|entry|rant|none), seed_id,
  status(open|reviewed), created_at, completed_at

brainstorm_responses
  id, session_id, prompt_key, prompt_text,
  answers(jsonb),          -- array of strings; length > 1 is normal
  starred_index(int null),
  disposition(pending|sent|kept|discarded), sent_to_entry_id

prompt_library
  id, key, topic, project_types(text[]), question, hint,
  alternates(jsonb), followup_rules(jsonb), order_index

canvases
  id, project_id, name, document(jsonb), created_at, updated_at

canvas_refs
  id, canvas_id, shape_id, entry_id      -- binds a canvas shape to a live entry

gap_dismissals
  id, project_id, gap_key, dismissed_at
```

`module_definitions.entry_schema` gains a `gap_rules` array so Tier 1 detection is declared alongside the module rather than hardcoded.

---

## 14. Revised build order

**Phase 1 — MVP**
Everything in v0.2 phase 1, plus: Project Overview with identity block and Pulse counts, Tier 1 rule-based gap detection, Prompted Brainstorm with a hand-written prompt library for the Novel vertical.

*Ship criterion, revised:* someone who knows only that they want to write a novel can use this for six weeks and end with a filled-in Character Sheet, a three-act outline, and an Overview that tells them what they've made.

**Phase 2**
Freeform Canvas with live entry cards. Tier 2 semantic gap detection. Generated "another angle" rephrasings. Prompt libraries for academic and professional verticals. Rant recurrence surfacing.

**Phase 3**
Custom modules, custom prompt sets, shareable templates, offline PWA.

---

## 15. Open questions

1. **Where does an "idea" live?** The Pulse shows `IDEAS 47`. Is that a module of its own, or a count of unsorted rant fragments and unreviewed brainstorm answers? *Recommendation: a real module, since it needs to be browsable, but auto-fed from unrouted brainstorm answers.*
2. **Prompt library size.** A good character-motivation set is maybe 10–15 questions with alternates. Across six topics and four project types that's several hundred well-written questions. This is the single largest content task in the product and should be scheduled as such.
3. **Does the canvas need real-time sync?** Single-user makes this much easier; if collaboration ever arrives, canvas CRDTs are the hardest part of it.
4. **Semantic gap quality bar.** A weak question is dismissible and cheap. A *confidently wrong* one erodes trust in the whole feature. Worth testing on real projects before it ships on by default anywhere.
