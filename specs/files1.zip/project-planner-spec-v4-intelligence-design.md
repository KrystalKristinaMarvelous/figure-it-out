# Spec v0.4 — Intelligence, Open Questions, Chaos Mode & Design Direction

**Supplements:** v0.2 (modules, rant space, data model) and v0.3 (overview, brainstorming)
**Covers:** §16 Architecture · §17 Open Questions · §18 Intelligence layer · §19 Chaos Mode · §20 Design direction

---

## 16. Architecture

### 16.1 The engine

The engine is four objects. Everything else is a service over them or a presentation of them.

```
PROJECT                       a container with a type and a readiness state
   └── MODULES                which structured tools this project has (config)
         └── ENTRIES          the actual content (characters, sources, beats, questions)
               └── LINKS      typed edges between entries, rants, and questions
```

Then three cross-cutting services, each of which reads and writes entries but is not a layer beneath them:

| Service | What it does |
|---|---|
| **Capture** | Rant space. Unstructured in, triaged out. |
| **Prompting** | Prompt library, brainstorm sessions, Chaos Mode. Generates candidates. |
| **Intelligence** | Gap detection, contradiction finding, Ask Project. Reads across entries, writes nothing without consent. |

And presentations, which are *how* modules render rather than things in the stack: sheet, slots, list, board, table, timeline, gallery, canvas.

This is a correction to the vertical chain sketched earlier. Boards, Timeline, and Research aren't layers below Connections — Board and Timeline are **presentations**, Research is a **module**, and AI is a **service**, not a floor of the building. Getting this right matters because it determines what's shared: any new module inherits search, linking, gap rules, and Chaos Mode participation for free.

### 16.2 Templates on top

```
                        ENGINE
                          │
      ┌───────────┬───────┴────────┬────────────┐
      ↓           ↓                ↓            ↓
   CREATIVE     ACADEMIC      PROFESSIONAL   PERSONAL
      │           │                │            │
  Characters   Question        Problem      Portfolio
  World        Sources         Customers    Sitemap
  Plot         Argument        Offer        Itinerary
  Scenes       Method          Roadmap      Milestones
  Themes       Data            Competitors  Budget
```

A template is a named list of module keys plus prompt-library scoping. Nothing more. Adding "Screenwriting" as a project type is a config file, not a release.

**This is the actual product claim:** it's not a writing app with other modes bolted on. It's a general-purpose ideation environment whose verticals happen to start with fiction because fiction has the best-documented scaffolds to copy.

---

## 17. Open Questions

The spine of the product, and the feature that gives the process a sense of progression.

### 17.1 Why it's the primary metric

Word count measures writing. This app's promise is *figure it out first* — so the honest unit of progress is **questions resolved**. A project with no draft has no word count, but it can have twenty-three answered questions, and that number means something real.

The Overview should lead with it:

```
  You've figured out 23 things about this project.
  14 still open.
```

Not a percentage. There's no denominator — you don't know how many questions a project has until it's done — and a fake percentage on a creative project is worse than no number.

### 17.2 Where questions come from

| Source | Mechanism |
|---|---|
| Brainstorm | "I don't know yet" on any prompt writes the prompt in as a question |
| Gap detection | Tier 1 and Tier 2 findings, when the user taps *keep this* |
| Chaos Mode | Any generated provocation the user keeps |
| Rant triage | Send a rant fragment to Open Questions |
| Manual | Typed directly, from anywhere, via the command palette |

Because questions arrive from five directions, the module is never empty and never feels like homework.

### 17.3 Structure

```
Question {
  text
  priority     blocking | important | minor        (🔴 🟡 🟢)
  status       open | exploring | resolved
  answer       filled on resolution
  resolved_to  optional reference to the entry where the answer now lives
  linked       references to related entries
  source       brainstorm | gap | chaos | rant | manual
  created_at, resolved_at
}
```

**Blocking** means genuinely can't proceed without it — reserve it, or everything becomes red. Default new questions to *important*.

`exploring` matters: it marks a question you've opened a brainstorm on but not settled. Without it, everything is binary and the middle of the work is invisible.

### 17.4 Resolution

Marking solved requires writing the answer. This is the point of the whole system — the record of *what you decided* is more valuable than the checkbox.

Resolved questions archive rather than vanish, and the archive doubles as a decisions log: what you wondered, what you chose, when, and where it ended up. At month four this is the most valuable text in the project.

Optional: on resolution, offer to route the answer into a module field, the same way brainstorm answers route.

### 17.5 Display rules

- Open questions rising is **not** a warning state. Early on it's the main evidence of progress. No red badges, no counts styled as alerts.
- Sort by priority then age. Surface the three oldest *blocking* questions on the Overview.
- A question open more than 30 days gets a gentle "still stuck on this?" with a one-tap route into brainstorm or Chaos Mode. Dismissible, never repeated more than once a month.

---

## 18. Intelligence layer

Principle: **the app is a consultant, not an author.** It reads your project and asks better questions than you'd ask yourself. It does not write your prose.

Three hard rules across every feature here:

1. **Grounded or silent.** Every claim cites the entries it came from, clickable. If it can't cite, it doesn't say it.
2. **Questions over assertions.** A question fails gracefully; a wrong assertion erodes trust in the whole feature.
3. **Writes nothing.** Output is always ephemeral until the user explicitly takes it into a module or a question.

### 18.1 Ask Project

```
🧠  Why does my plot feel weak around Act II?

    You have three major events between the inciting incident
    and the midpoint — the Council summons, the letter, and
    the journey to Vell — but none of them changes Raven's
    situation. She wants the same thing, knows the same
    things, and has the same options after all three.

    Drawn from: Three-Act Structure · Scene Cards (3) · Raven

    [ Brainstorm complications ]   [ Log as open question ]
```

**Retrieval, not context-stuffing.** A mature project has hundreds of entries and won't fit in a prompt. v1 routes by module: parse which modules the question implicates, load those entries plus anything linked to them. Phase 2 adds embeddings over entries for semantic retrieval. Get this right early — it's the main engineering cost of the whole AI layer, and a model reasoning over the wrong twelve entries gives confidently irrelevant answers.

Every answer ends in an action. An observation the user can't act on is a dead end.

### 18.2 Find Contradictions

#### Tier 1 — Deterministic (MVP, no model)

> Raven is listed as 17 during the Winter Ball, but your timeline places the Winter Ball two years after her 18th birthday.

This is date arithmetic. It requires no model, is never wrong, runs instantly, costs nothing, and works offline.

**It does require typed fields.** This is a schema requirement flowing backward into v0.2's module definitions:

- Character Sheet: structured `birth_year` / `age_at` rather than prose
- Timeline events: real `date` values, on the project's own calendar if it's secondary-world
- Scene Cards: `date` or timeline reference, plus character references
- Locations: referenced, not typed as free text

Checks available once that holds:

| Check | Example |
|---|---|
| Age vs. event date | The one above |
| Ordering | A character appears in a scene dated before their introduction |
| Existence | A character appears in a scene after their recorded death |
| Uniqueness | Two entries claim the same unique role or title |
| Dangling reference | A location is mentioned in four scenes but never defined |
| Arithmetic | Chapter word targets sum to 62,000 against an 80,000 target |
| Academic | Method states n=40; the data module has 31 rows |

#### Tier 2 — Semantic (phase 2, opt-in)

Motivation incoherence, stated theme versus what the scenes actually do, a character's established voice contradicted by their dialogue, a research conclusion overreaching its stated method. Always phrased as a question, capped at three, individually and permanently dismissible.

### 18.3 What the AI never does

- Write prose, scenes, or dialogue for the project
- Fill module fields without explicit acceptance
- Assert facts about the work's quality or meaning
- Generate content offered as the user's own

The pitch is *don't write it yet, figure it out first*. A tool that writes it for you contradicts its own premise.

---

## 19. Chaos Mode

For when you're stuck. Takes what's already in your project and recombines it into provocations.

### 19.1 The mechanism is a random walk, not a model

Every one of these is a template filled from randomly selected entries:

```
What if {character.A} is wrong about {character.B}?
Who benefits most from {event}?
What happens if {event} moves five years later?
What would happen if {character} knew {secret_or_question}?
How could {entry.X} and {entry.Y} be connected?     ← different modules
What if {established_rule} has an exception?
Which of these is a lie: {fact.A} or {fact.B}?
What does {character} want that you haven't written down?
Remove {entry}. What breaks?
```

Real randomness over the entry graph produces genuine surprise, costs nothing, and **cannot hallucinate** — every noun in the question is something the user wrote. Ship this in the MVP. Generated provocations are a phase-2 layer over the same mechanism, not a replacement for it.

Selection is weighted toward pairs with *no existing link*, since the useful surprises come from connecting things you've kept apart.

### 19.2 Session

Five cards, one at a time. Per card: **[ Reroll ]** · **[ Keep as question ]** · **[ Brainstorm this ]** · **[ Nothing here ]**.

"Nothing here" is recorded and quietly down-weights that template — the library learns per user which provocations land.

Rules: always a question, never a suggestion. Nothing is written to the project unless taken. Requires a minimum of roughly ten entries; below that it offers the Prompted Brainstorm instead, since chaos needs material to be chaotic with.

### 19.3 Where it lives

Available from the command palette anywhere, from the Overview when a project has been untouched a while, and offered when a question has sat blocked for weeks. Not a tab — it's a state you enter and leave.

---

## 20. Design direction

Reference points: Scrivener's density, Milanote's materiality, Obsidian's connectedness, a working studio rather than an office.

### 20.1 The organizing idea

**Colour encodes uncertainty.** A single accent is reserved exclusively for *unresolved* state — open questions, empty required fields, unreviewed brainstorm sessions, uncited sources. Everything settled renders monochrome.

The consequence is that a project visibly **quiets down as you figure it out**, and the amount of colour on any screen tells you at a glance how much is still unknown. Colour is doing structural work rather than decoration, and it's tied directly to the product's promise.

Spend the boldness here and keep everything else disciplined.

### 20.2 Tokens

```
Light                              Dark
surface       #E7EAE9              #16191B
raised        #F2F4F3              #1E2225
ink           #14171A              #E9EDEC
muted         #697178              #8A9299
hairline      #C9CFCE              #2C3134

unresolved    #B8177A              #E24BA4      the only accent; state, not decoration
chaos         #4B34E8              #7C68FF      Chaos Mode only, nowhere else
```

Deliberately not the warm-cream-plus-terracotta palette that every "creative tool" lands on. The base is a cool, slightly green-grey — closer to a studio wall than to paper — so the magenta reads as a signal rather than a mood.

Per-project accent themes are supported, but they tint chrome only. The unresolved colour is constant across all projects, because it means something.

Dark mode is built from the same token set on day one. Retrofitting it later is the expensive path.

### 20.3 Type

Two families with a real division of labour:

- **The app's voice is serif.** Every prompt, every question, every gap finding, every Chaos card. `Newsreader` or similar, generous line height, ~66 character measure.
- **The user's structure is sans.** Field labels, module names, navigation, counts, tables. `Instrument Sans` or similar.

So the tool's questions and the user's material are typographically distinct, everywhere, without a single label saying so. When the app asks you something, it looks different from when you tell it something.

Avoid: all-caps labels, one accented word in a headline, eyebrow labels above every heading, monospace for small data labels.

### 20.4 Surface

Cards differentiate by border weight and background tint, not by drop shadow. Small radius (3px), hairline borders, no soft grey shadows under everything. Density is a feature — this is a tool for people with a lot of material, and generous whitespace everywhere makes a mature project feel emptier than it is.

Entry cards vary in size by content type. Identical rounded rectangles for a character, a source, and a scene would be the wrong information design.

### 20.5 Motion

**One orchestrated moment: resolving a question.** The accent drains out of the card, the card settles, the resolved count ticks up. That's the core loop of the entire product and it should feel good every single time.

Everything else is instant. No fade-and-slide entrances on module loads, no hover transitions on every card. Motion answers actions — opening, expanding, confirming — and otherwise stays out of the way. Respect `prefers-reduced-motion` throughout.

### 20.6 Interaction essentials

Ranked by value per unit of work:

1. **Command palette (⌘K)** — highest value, lowest cost. Jump to any entry, add a card to any module, start a brainstorm, open Chaos Mode, log a question. This is what makes the app feel fast and what power users will judge it on.
2. **Global capture hotkey** — rant from anywhere, over anything.
3. **Search** — full text across entries, rants, transcripts, and questions, grouped by module.
4. **Keyboard navigation** in every list and sheet.
5. Per-project accent themes.

Explicitly not doing: streaks, confetti, badges, gamified completion. The audience is people making serious things, and creative work is intermittent by nature.

### 20.7 Empty states

Every empty module shows a filled-in example plus one action. Never "No entries yet."

> **Characters**
> Nobody here yet. Most people start with whoever the story is happening to.
> [ Add a character ]  ·  [ Brainstorm one ]

---

## 21. Positioning

**Don't write it yet. Figure it out first.**

The competitive claim underneath it: Scrivener, Notion, and Docs all assume you know what you're making. This is for the stretch before that — where you have material but not shape — and it's the only stretch where a tool can offer something better than a blank page.

---

## 22. Revised build order

**Phase 1 — MVP**
v0.2 and v0.3 phase 1, plus: Open Questions module wired to all five sources, "questions figured out" as the Overview's headline metric, Tier 1 deterministic contradiction checks, Chaos Mode with template-based random-walk provocations, command palette, dark mode.

*Note: everything above is achievable without a single model call.* The MVP is a complete, useful product with the AI switched off entirely — which is the right position to build from.

**Phase 2**
Ask Project with module-routed retrieval. Tier 2 semantic contradictions and gaps. Generated Chaos provocations and brainstorm rephrasings. Freeform canvas. Academic and professional prompt libraries.

**Phase 3**
Custom modules and prompt sets, shareable templates, embeddings-based retrieval, offline PWA.

---

## 23. Open questions

1. **Typed-field friction.** Deterministic contradiction checking needs structured dates and ages, but forcing a novelist to enter a birth year before they know it is hostile. Likely answer: fields accept prose *or* structure, and checks run only on the structured ones — with a quiet "make this a date?" affordance.
2. **Secondary-world calendars.** Fantasy projects need their own calendar for date arithmetic to work at all. Real feature, non-trivial, probably phase 2.
3. **Chaos Mode template count.** Twenty templates will feel repetitive within a week. Needs a hundred-plus, plus the down-weighting mechanism, plus per-project-type variants.
4. **Retrieval quality gate.** Ask Project is only as good as which twelve entries it reads. Worth testing on a deliberately large synthetic project before it ships.
5. **Where the accent stops.** If too many things count as "unresolved," the screen is always magenta and the signal dies. Needs a tight, tested definition of the unresolved set.
